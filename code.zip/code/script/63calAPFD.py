
import os
import re
import shutil
import  xml.dom.minidom
from bs4 import BeautifulSoup
import random

#file have the handled subject list
#SubjectListFile = 'anonymous/projects/hbase-1.2.2/SuccessFile.txt'# anonymous processing
SubjectRootPath = 'anonymous/projects'# anonymous processing

sequenceType = [
'SequenceTTStatement.txt',
'SequenceTTMethod.txt',
'SequenceGeneticStatement.txt',
'SequenceGeneticMethod.txt',
'SequenceGAStatement.txt',
'SequenceGAMethod.txt',
'SequenceARTStatement.txt',
'SequenceARTMethod.txt',
'SequenceTime.txt',
'SequenceTimeAdditionalStatement.txt',
'SequenceTimeAdditionalMethod.txt',
'SequenceDoubleTimeAdditionalStatement.txt',
'SequenceDoubleTimeAdditionalMethod.txt'
]

APFDType = [
'APFDTTStatement.txt',
'APFDTTMethod.txt',
'APFDGeneticStatement.txt',
'APFDGeneticMethod.txt',
'APFDGAStatement.txt',
'APFDGAMethod.txt',
'APFDARTStatement.txt',
'APFDARTMethod.txt',
'APFDTime.txt',
'APFDTimeAdditionalStatement.txt',
'APFDTimeAdditionalMethod.txt',
'APFDDoubleTimeAdditionalStatement.txt',
'APFDDoubleTimeAdditionalMethod.txt'
]
mutantSum = 0
testSum = 0
groupSum = 0


def readKillMatrix(readMutantPath):
	'''
	readfile = open(readTestPath)
	lines = readfile.readlines()
	testSum = len(lines)
	readfile.close()
	'''
	global mutantSum
	global groupSum
	readfile = open(readMutantPath)
	lines = readfile.readlines()
	mutantSum = len(lines)
	readfile.close()
	groupSum = mutantSum / 5
	#killMatrix = [[0 for col in range(testSum)] for row in range(mutantSum)]
	killMatrix = []
	for line in lines:
		kills = list(line.strip())
		killMatrix.append(kills)
	return killMatrix

def readSubjectList(readFilePath):
	SubjectList = []
	readFile = open(readFilePath)
	for line in readFile:
		SubjectList.append(line.strip())
	readFile.close()
	return SubjectList

def readTestList(readpath):
	global testSum
	testMap = {}
	count = 0
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		testMap[line] = count
		count = count + 1
	readfile.close()
	testSum = count
	return testMap

def calculateAPFD(readpath, writepath, mutantGroup, killMatrix, TestMap):
	global groupSum
	sequence = []
	print groupSum
	#translate the sequence 
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		sequence.append(TestMap[line])
	readfile.close()

	writefile = open(writepath, 'w')
	for i in range(0, groupSum):
		mutantlist = []
		for j in range(0, 5):
			mutantlist.append(mutantGroup[i][j])
		APFDvalue = singleAPFD(sequence, mutantlist, killMatrix)
		print APFDvalue
		writefile.write(str(APFDvalue) + '\n')
	writefile.close()

def singleAPFD(sequence, mutantlist, killMatrix):
	global testSum
	APFDvalue = 0
	tmpMutantList = []
	for i in range(0, testSum - 1):
		currentTest = sequence[i]
		for j in range(0, 5):
			 currentMutant = mutantlist[j]
			 if killMatrix[currentMutant][currentTest] == '1' and currentMutant not in tmpMutantList:
				tmpMutantList.append(currentMutant)
		APFDvalue = APFDvalue + len(tmpMutantList)
	APFDvalue = ( APFDvalue * 1.0 / 5) / testSum + 0.5 / testSum
	return APFDvalue

def readMutantGroup(readpath):
	readfile = open(readpath)
	lines = readfile.readlines()
	readfile.close()
	mutantGroup = []
	for line in lines:
		line = line.strip()
		items = line.split(' ')
		tmp = []
		for item in items:
			tmp.append(int(item))
		mutantGroup.append(tmp)
	return mutantGroup


if __name__ == '__main__':
	SubjectList = readSubjectList(SubjectRootPath + '/SuccessSubjectList.txt')
	for sub in SubjectList:
		print 'SUBJECT ' + sub
		subpath = SubjectRootPath + '/R' + sub
		killMatrix = readKillMatrix(subpath + '/mutant/' + sub + '/mutantKillMatrix')
		TestMap = readTestList(subpath + '/coverage/' + sub + '/testList')
		#mutantGroup = generateMutantGroup(SubjectRootPath + '/result/' + sub + '/mutantGroup')
		mutantGroup = readMutantGroup(subpath + '/result/' + sub + '/mutantGroup')
		print mutantGroup
		for i in range(0, 13):
			readdir = subpath + '/result/' + sub + '/'
			calculateAPFD(readdir + sequenceType[i],  readdir + APFDType[i],  mutantGroup,  killMatrix, TestMap)
