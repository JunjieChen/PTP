
import os
import re
import shutil
import  xml.dom.minidom
from bs4 import BeautifulSoup
import random

#file have the handled subject list
#SubjectListFile = 'anonymous/projects/hbase-1.2.2/SuccessFile.txt'# anonymous processing
SubjectRootPath = 'anonymous/projects' # anonymous processing

sequenceType = [
'SequenceTTStatement.txt',
'SequenceTTMethod.txt',
'SequenceGeneticStatement.txt',
'SequenceGeneticMethod.txt',
'SequenceGAStatement.txt',
'SequenceGAMethod.txt',
'SequenceARTStatement.txt',
'SequenceARTMethod.txt',
'SequenceTime.txt',
'SequenceTimeAdditionalStatement.txt',
'SequenceTimeAdditionalMethod.txt',
'SequenceDoubleTimeAdditionalStatement.txt',
'SequenceDoubleTimeAdditionalMethod.txt'
]


APFDType = [
'APFDcTTStatement.txt',
'APFDcTTMethod.txt',
'APFDcGeneticStatement.txt',
'APFDcGeneticMethod.txt',
'APFDcGAStatement.txt',
'APFDcGAMethod.txt',
'APFDcARTStatement.txt',
'APFDcARTMethod.txt',
'APFDcTime.txt',
'APFDcTimeAdditionalStatement.txt',
'APFDcTimeAdditionalMethod.txt',
'APFDcDoubleTimeAdditionalStatement.txt',
'APFDcDoubleTimeAdditionalMethod.txt'
]
mutantSum = 0
testSum = 0
groupSum = 0
timeSum = 0


def readKillMatrix(readMutantPath):
	'''
	readfile = open(readTestPath)
	lines = readfile.readlines()
	testSum = len(lines)
	readfile.close()
	'''
	global mutantSum
	global groupSum
	readfile = open(readMutantPath)
	lines = readfile.readlines()
	mutantSum = len(lines)
	readfile.close()
	groupSum = mutantSum / 5
	#killMatrix = [[0 for col in range(testSum)] for row in range(mutantSum)]
	killMatrix = []
	for line in lines:
		kills = list(line.strip())
		killMatrix.append(kills)
	return killMatrix

def readSubjectList(readFilePath):
	SubjectList = []
	readFile = open(readFilePath)
	for line in readFile:
		SubjectList.append(line.strip())
	readFile.close()
	return SubjectList

def readTestList(readpath):
	global testSum
	testMap = {}
	count = 0
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		testMap[line] = count
		count = count + 1
	readfile.close()
	testSum = count
	return testMap
	
def readTimeList(readpath):
	global timeSum
	timeSum = 0
	timeList = []
	readfile = open(readpath)
	for line in readfile:
		line = float(line.strip())
		timeSum = timeSum + line
		timeList.append(line)
	readfile.close()
	return timeList


def calculateAPFD(readpath, writepath, mutantGroup, killMatrix, TestMap, timeList):
	global groupSum
	sequence = []
	print groupSum
	#translate the sequence 
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		sequence.append(TestMap[line])
	readfile.close()

	writefile = open(writepath, 'w')
	for i in range(0, groupSum):
		mutantlist = []
		for j in range(0, 5):
			mutantlist.append(mutantGroup[i][j])
		APFDvalue = singleAPFD(sequence, mutantlist, killMatrix, timeList)
		print APFDvalue
		writefile.write(str(APFDvalue) + '\n')
	writefile.close()

def singleAPFD(sequence, mutantlist, killMatrix, timeList):
	global testSum
	global timeSum
	APFDvalue = 0
	tmpMutantList = []
	for i in range(0, 5):
		currentMutant = mutantlist[i]
		tmpcount = 0
		for j in range(0, testSum):
			currentTest = sequence[j]
			if killMatrix[currentMutant][currentTest] == '1':
				for k in range(j, testSum):
					tmpTest = sequence[k]
					tmpcount = tmpcount + timeList[tmpTest]
				tmpcount = tmpcount - 0.5 * timeList[currentTest]
				break
		APFDvalue = APFDvalue + tmpcount
	APFDvalue = APFDvalue*1.0/ (timeSum * 5)
	return APFDvalue 

def readMutantGroup(readpath):
	readfile = open(readpath)
	lines = readfile.readlines()
	readfile.close()
	mutantGroup = []
	for line in lines:
		line = line.strip()
		items = line.split(' ')
		tmp = []
		for item in items:
			tmp.append(int(item))
		mutantGroup.append(tmp)
	return mutantGroup

def readSubjectList(readFilePath):
	SubjectList = []
	readFile = open(readFilePath)
	for line in readFile:
		SubjectList.append(line.strip())
	readFile.close()
	return SubjectList

if __name__ == '__main__':
	SubjectList = readSubjectList(SubjectRootPath + '/SuccessSubjectList.txt')
	for sub in SubjectList:
		print 'SUBJECT ' + sub
		subpath = SubjectRootPath + '/R' + sub
		killMatrix = readKillMatrix(subpath + '/mutant/' + sub + '/mutantKillMatrix')
		TestMap = readTestList(subpath + '/coverage/' + sub + '/testList')
		#mutantGroup = generateMutantGroup(SubjectRootPath + '/result/' + sub + '/mutantGroup')
		mutantGroup = readMutantGroup(subpath + '/result/' + sub + '/mutantGroup')
		timeList = readTimeList(subpath + '/result/' + sub + '/exeTime')
		for i in range(0, 13):
			readdir = subpath + '/result/' + sub + '/'
			calculateAPFD(readdir + sequenceType[i],  readdir + APFDType[i],  mutantGroup,  killMatrix, TestMap, timeList)
