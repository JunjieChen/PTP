import os
import datetime
import os.path
import subprocess as subp
import sys
import thread
import math

def normalize(sortlist,number):
	if number>0:
		minvalue=0.0
	else:
		minvalue=sortlist[0]
	maxvalue=sortlist[len(sortlist)-1]
	fenmu=maxvalue-minvalue
	normalizedlist=[]
	for i in range(len(sortlist)):
		normalizedlist.append((sortlist[i]-minvalue)/fenmu)
	return normalizedlist


#projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','chromecast-java-api-v2','geo','are-we-consistent-yet','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master']
projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','geo','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master','commons-dbcp','blueflood','commons-io','hivemall','languagetool','stream-lib','jsprit','RoaringBitmap','commons-math']
#filelist=['exeTime']

#tec=['TotalStmt','AddiStmt.txt','GeneticStmt','ARTStmt','TotalMethod','AddiMethod','GeneticMethod','ARTMethod',]

parrootdir='../data/oldtime/ratio'

result=open('featureoriset.csv','w')

maxtestnumber=10309
resulttmp=[]
for k in range(maxtestnumber*3):
	resulttmp.append(str(k+1))
result.write(','.join(resulttmp)+'\n')

for k in range(len(projects)):
	pro=projects[k]
	if 'php-' in pro:
		rootdir=parrootdir
		
		curfile=open(rootdir+'/'+pro+'ratio.csv')
		curlines=curfile.readlines()
		curfile.close()

		beforesort=[]
		bound=len(curlines)
		for j in range(1,bound):
			value=float(curlines[j].strip().split(',')[1])
			beforesort.append(value)
		beforesort.sort()
		afternormal=normalize(beforesort,maxtestnumber-(bound-1))

		tmpresult=[]
		for j in range(maxtestnumber-(bound-1)):
			tmpresult.append(str(0))
		for j in range(1,bound):
			tmpresult.append(str(afternormal[j-1]))
		result.write(','.join(tmpresult)+',')

		beforesort=[]
		bound=len(curlines)
		for j in range(1,bound):
			value=float(curlines[j].strip().split(',')[0])
			beforesort.append(value)
		beforesort.sort()
		afternormal=normalize(beforesort,maxtestnumber-(bound-1))

		tmpresult=[]
		for j in range(maxtestnumber-(bound-1)):
			tmpresult.append(str(0))
		for j in range(1,bound):
			tmpresult.append(str(afternormal[j-1]))
		result.write(','.join(tmpresult)+',')

		beforesort=[]
		bound=len(curlines)
		for j in range(1,bound):
			value=float(curlines[j].strip().split(',')[1])/float(curlines[j].strip().split(',')[0])
			beforesort.append(value)
		beforesort.sort()
		afternormal=normalize(beforesort,maxtestnumber-(bound-1))

		tmpresult=[]
		for j in range(maxtestnumber-(bound-1)):
			tmpresult.append(str(0))
		for j in range(1,bound):
			tmpresult.append(str(afternormal[j-1]))
		result.write(','.join(tmpresult)+'\n')
	else:
		rootdir=parrootdir
		
		curfile=open(rootdir+'/'+pro+'ratio.csv')
		curlines=curfile.readlines()
		curfile.close()

		beforesort=[]
		bound=len(curlines)
		for j in range(1,bound):
			value=float(curlines[j].strip().split(',')[1])
			beforesort.append(value)
		beforesort.sort()
		afternormal=normalize(beforesort,maxtestnumber-(bound-1))

		tmpresult=[]
		for j in range(maxtestnumber-(bound-1)):
			tmpresult.append(str(0))
		for j in range(1,bound):
			tmpresult.append(str(afternormal[j-1]))
		result.write(','.join(tmpresult)+',')

		beforesort=[]
		bound=len(curlines)
		for j in range(1,bound):
			value=float(curlines[j].strip().split(',')[0])/1000
			beforesort.append(value)
		beforesort.sort()
		afternormal=normalize(beforesort,maxtestnumber-(bound-1))

		tmpresult=[]
		for j in range(maxtestnumber-(bound-1)):
			tmpresult.append(str(0))
		for j in range(1,bound):
			tmpresult.append(str(afternormal[j-1]))
		result.write(','.join(tmpresult)+',')

		beforesort=[]
		bound=len(curlines)
		for j in range(1,bound):
			value=float(curlines[j].strip().split(',')[1])/(float(curlines[j].strip().split(',')[0])/1000)
			beforesort.append(value)
		beforesort.sort()
		afternormal=normalize(beforesort,maxtestnumber-(bound-1))

		tmpresult=[]
		for j in range(maxtestnumber-(bound-1)):
			tmpresult.append(str(0))
		for j in range(1,bound):
			tmpresult.append(str(afternormal[j-1]))
		result.write(','.join(tmpresult)+'\n')
result.close()
