import os
import datetime
import os.path
import subprocess as subp
import sys
import thread
import math

#projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','chromecast-java-api-v2','geo','are-we-consistent-yet','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master']
projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','geo','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master','commons-dbcp','blueflood','commons-io','hivemall','languagetool','stream-lib','jsprit','RoaringBitmap','commons-math']
#filelist=['exeTime']

#tec=['TotalStmt','AddiStmt.txt','GeneticStmt','ARTStmt','TotalMethod','AddiMethod','GeneticMethod','ARTMethod',]
rootdir='../data/oldtime'

filelist=['APFDcGAStatement.txt','APFDcTimeAdditionalStatement.txt','APFDcTime.txt']

result=open('labeloriset.csv','w')
for pro in projects:
	if 'php' in pro:
		propath=rootdir+'/'+pro+'/mutationresult'
	else:
		propath=rootdir+'/'+pro
	#for i in range(50):
	result.write(pro+',0,')
	numpropath=propath
	
	file1=open(numpropath+'/'+filelist[0])
	lines1=file1.readlines()
	file1.close()

	file2=open(numpropath+'/'+filelist[1])
	lines2=file2.readlines()
	file2.close()

	file3=open(numpropath+'/'+filelist[2])
	lines3=file3.readlines()
	file3.close()

	rank=[]

	sum1=0.0
	sum2=0.0
	sum3=0.0

	if len(lines1)>100:
		bound=100
	else:
		bound=len(lines1)

	for j in range(bound):

		sum1+=float(lines1[j].strip())
		sum2+=float(lines2[j].strip())
		sum3+=float(lines3[j].strip())

	rank.append(sum1)
	rank.append(sum2)
	rank.append(sum3)
	rank.sort()

	if sum1>sum2 and sum1>sum3:
		result.write('a,')
	if sum2>sum1 and sum2>sum3:
		result.write('b,')
	if sum3>sum1 and sum3>sum2:
		result.write('c,')

	result.write(str((rank[2]-rank[1])/bound)+'\n')
result.close()




