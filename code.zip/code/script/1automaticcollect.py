import os 
import shutil




RootPath = 'anonymous/projects/' # anonymous processing
SubjectList = ['mapdb-mapdb-1.0.9'] # project lists


def getSonSubList(BigSubpath):
	SonSubList = []
	files = os.listdir(BigSubpath)
	for item in files:
		subpath = BigSubPath + '/' + item
		if os.path.exists(subpath) and os.path.isdir(subpath) and os.path.exists(subpath + '/pom.xml'):
			SonSubList.append(item)
	return SonSubList

def collectCoverage(BigSubPath, item):
	subpath = BigSubPath + '/' + item
	if os.path.exists(subpath + '/cloverResult'):
		shutil.rmtree(subpath + '/cloverResult')
	os.mkdir(subpath + '/cloverResult')
	os.chdir(subpath)
	#collect Statement Coverage
	print 'collect Statement'
	if os.path.exists(subpath + '/statementLog.txt'):
		os.remove(subpath + '/statementLog.txt')
	cmd = "mvn clean clover:setup -Dmaven.clover.instrumentation=statement test clover:aggregate clover:clover >> statementLog.txt"
	os.system(cmd)
	if os.path.exists(subpath + '/target/site') and os.path.isdir(subpath + '/target/site'):
		if os.path.exists(subpath + '/cloverResult/statement') == False:
			os.mkdir(subpath + '/cloverResult/statement')
		cmd = 'cp -rf ' + subpath + '/target/site ' + subpath + '/cloverResult/statement'
		os.system(cmd)
	#collect Method Coverage
	
	
	
	print 'collect Method'
	if os.path.exists(subpath + '/methodLog.txt'):
		os.remove(subpath + '/methodLog.txt')
	cmd = "mvn clean clover:setup -Dmaven.clover.instrumentation=method test clover:aggregate clover:clover >> methodLog.txt"
	os.system(cmd)
	if os.path.exists(subpath + '/target/site') and os.path.isdir(subpath + '/target/site'):
		if os.path.exists(subpath + '/cloverResult/method') == False:
			os.mkdir(subpath + '/cloverResult/method')
		cmd = 'cp -rf ' + subpath + '/target/site ' + subpath + '/cloverResult/method'
		os.system(cmd)


	'''
	#collect BranchCoverage
	print 'collect Branch'
	if os.path.exists(subpath + '/branchLog.txt'):
		os.remove(subpath + '/branchLog.txt')
	cmd = "mvn clean clover:setup -Dmaven.clover.instrumentation=branch test clover:aggregate clover:clover >> branchLog.txt"
	os.system(cmd)
	if os.path.exists(subpath + '/target/site') and os.path.isdir(subpath + '/target/site'):
		if os.path.exists(subpath + '/cloverResult/branch') == False:
			os.mkdir(subpath + '/cloverResult/branch')
		cmd = 'cp -rf ' + subpath + '/target/site ' + subpath + '/cloverResult/branch'
		os.system(cmd)
	'''
	
	writeLog = open(BigSubPath + '/cloverConclusion.txt', 'a')
	writeLog.write('SUB:' + item + '\n')
	
	
	exeTime = analysisTime('statementLog.txt')
	writeLog.write('statement ' + exeTime + ' ')
	if analysisSuccess('statementLog.txt'):
		writeLog.write('SUCESS' + '\n')
	else:
		writeLog.write('FAIL' + '\n')
	
	
	exeTime = analysisTime('methodLog.txt')
	writeLog.write('method ' + exeTime + ' ')
	if analysisSuccess('methodLog.txt'):
		writeLog.write('SUCESS' + '\n')
	else:
		writeLog.write('FAIL' + '\n')
	

	'''
	exeTime = analysisTime('branchLog.txt')
	writeLog.write('branch ' + exeTime + ' ')
	if analysisSuccess('branchLog.txt'):
		writeLog.write('SUCESS' + '\n')
	else:
		writeLog.write('FAIL' + '\n')
	'''
	writeLog.close()

# judge whether made success
def analysisSuccess(filePath):
	flag = False
	fileread = open(filePath)
	for line in fileread:
		line = line.strip()
		if '[INFO] BUILD SUCCESS' in line:
			flag = True
			break
	fileread.close()
	return flag

# judge whether made success
def analysisTime(filePath):
	exeTime = 'NoTime'
	fileread = open(filePath)
	for line in fileread:
		line = line.strip()
		if '[INFO] Total time:' in line:
			exeTime = line.split('Total time:')[1]
			break
	fileread.close()
	return exeTime

if __name__ == "__main__":
	for item in SubjectList:
		print 'Big sub ' + item
		BigSubPath = RootPath + item
		collectCoverage(BigSubPath, '')
		
		'''
		SonSubList = getSonSubList(BigSubPath)
		
		for sub in SonSubList:
			print 'Small ' + item + ' ' + sub 
			collectCoverage(BigSubPath, sub)
		'''