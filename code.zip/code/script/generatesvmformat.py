import os
import datetime
import os.path
import subprocess as subp
import sys
import thread

os.system('mkdir trainsvm')
for fi in os.listdir('anonymous/train'): # anonymous processing
	f=open('anonymous/train/'+fi) # anonymous processing
	lines=f.readlines()
	f.close()

	result=open('./trainsvm/'+fi[:-4]+'.svm.txt','w')
	for i in range(1,len(lines)):
		resultlist=[]
		tmplist=lines[i].strip().split(',')
		if tmplist[-1]=='a':
			resultlist.append(str(0))
		if tmplist[-1]=='b':
			resultlist.append(str(1))
		if tmplist[-1]=='c':
			resultlist.append(str(2))

		for j in range(len(tmplist)-1):
			resultlist.append(str(j+1)+':'+tmplist[j])

		result.write(' '.join(resultlist)+'\n')
	result.close()


