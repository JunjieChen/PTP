import os
import re
import shutil
import  xml.dom.minidom
from bs4 import BeautifulSoup

#file have the handled subject list
#SubjectListFile = 'anonymous/projects/hbase-1.2.2/SuccessFile.txt'# anonymous processing
SubjectRootPath = 'anonymous/projects/' # anonymous processing
ResultRootPath = 'anonymous/projects/Rchukwa/coverage' # anonymous processing
prefix = 'org/apache/hadoop/chukwa/' #prefix of subject


'''
def GetSuccessFile(readFilePath, writeFilePath):
	SubjectList = []
	Flag = True
	tmpName = ''
	readFile = open(readFilePath)
	for line in readFile:
		line = line.strip()
		if line.startswith('SUB:'):
			Flag = True
			tmpName = line.replace('SUB:', '')
		elif line.startswith('method'):
			if 'FAIL' in line:
				Flag = False
		elif line.startswith('statement'):
			if 'FAIL' in line:
				Flag = False
		elif line.startswith('branch'):
			if 'FAIL' in line:
				Flag = False
			if Flag == True:
				SubjectList.append(tmpName)
	readFile.close()
	
	writeFile = open(writeFilePath, 'w')
	for item in SubjectList:
		writeFile.write(item + '\n')
	writeFile.close()
	
	return SubjectList
'''


#xml : src file list + test file list
#source hmtl: statement sum
#test html: id and test name map
#src js: coverage matrix 

def readSubjectList(readFilePath):
	SubjectList = []
	readFile = open(readFilePath)
	for line in readFile:
		SubjectList.append(line.strip())
	readFile.close()
	return SubjectList


#main analyze function
def anaMain(xmlFilePath, subName): #loc
	global prefix
	global ResultRootPath
	TestFileList = [] # from org/apache/handoop/xxxx (no .html)
	SrcFileList = [] 
	lineList = [] #index for global start line number for each src file
	MethodLineList = []
	ConditionLineList = []
	
	#get all needs test files to be analyzied
	dom = xml.dom.minidom.parse(xmlFilePath + '/clover.xml')
	root = dom.documentElement
	testproject = root.getElementsByTagName('testproject')[0]
	testpackages = testproject.getElementsByTagName('package')
	for package in testpackages:
		testfiles = package.getElementsByTagName('file')
		for testfile in testfiles:
			testfilepath = testfile.getAttribute('path')
			if prefix not in testfilepath:
				continue
			tmpptr = testfilepath.index(prefix)
			testfilepath = testfilepath[tmpptr:]
			testfilepath = testfilepath.replace('.java', '')
			if os.path.exists(xmlFilePath + '/' + testfilepath + '.html'):
				TestFileList.append(str(testfilepath))


	#get all needs sourcefiles tobe analyzied
	dom = xml.dom.minidom.parse(xmlFilePath + '/clover.xml')
	root = dom.documentElement
	project = root.getElementsByTagName('project')[0]
	#get total line number of whole project
	#lineNum = project.getElementsByTagName('metrics')[0]
	#lineNum = int(lineNum.getAttribute('loc'))
	srcpackages = project.getElementsByTagName('package')
	UnitNum = 0
	for srcpackage in srcpackages:
		srcfiles = srcpackage.getElementsByTagName('file')
		for srcfile in srcfiles:
			srcfilepath = srcfile.getAttribute('path')
			if prefix not in srcfilepath:
				continue
			tmpptr = srcfilepath.index(prefix)
			srcfilepath = srcfilepath[tmpptr:]
			srcfilepath = srcfilepath.replace('.java', '')
			if os.path.exists(xmlFilePath + '/' + srcfilepath + '.js'):
				#print srcfilepath + ' ' + str(UnitNum)
				SrcFileList.append(str(srcfilepath))
				fileunitnum = srcfile.getElementsByTagName('metrics')[0]
				fileunitnum = int(fileunitnum.getAttribute('loc'))
				lineList.append(UnitNum)
				lines = srcfile.getElementsByTagName('line')
				for lineItem in lines:
					if str(lineItem.getAttribute('type')) == 'method':
						methodLine = int(lineItem.getAttribute('num'))
						if (UnitNum + methodLine) not in MethodLineList:
							MethodLineList.append(UnitNum + methodLine)
							#print str(methodLine) + ' ' + str(UnitNum + methodLine)
					if str(lineItem.getAttribute('type')) == 'cond':
						condLine = int(lineItem.getAttribute('num'))
						if (UnitNum + condLine) not in ConditionLineList:
							ConditionLineList.append(UnitNum + condLine)
				UnitNum = UnitNum + fileunitnum


	#map id and test name
	mapIdName = mapTest(TestFileList, xmlFilePath)
	
	writefile = open(ResultRootPath +'/' + subName +  '/testList', 'w')
	for item in mapIdName:
		writefile.write(item + '\n')
	writefile.close()
	
	#create 2-division array c[i][j]: test i whther cover unit j

	testSum = len(mapIdName)
	UnitSum = UnitNum
	StateCovMatrix = [[0 for col in range(UnitSum)] for row in range(testSum)]
	MethodCovMatrix = [[0 for col in range(UnitSum)] for row in range(testSum)]
	CondCovMatrix = [[0 for col in range(UnitSum)] for row in range(testSum)]
	#analyze coverage information
	FillMatrixState(StateCovMatrix, MethodCovMatrix, CondCovMatrix, SrcFileList, lineList, MethodLineList, ConditionLineList, xmlFilePath, subName, testSum, UnitSum)


def FillMatrixState(StateCovMatrix, MethodCovMatrix, CondCovMatrix, SrcFileList, lineList, MethodLineList, ConditionLineList, xmlFilePath, subName, testSum, UnitSum):
	global ResultRootPath
	filePtr = 0
	debugcount = 0
	for srcFile in SrcFileList:
		#debugcount = debugcount + 1
		#if debugcount > 30:
		#	break
	
		currenPtr = lineList[filePtr]
		filePtr = filePtr + 1
		#print currenPtr
		FilePath = xmlFilePath + '/' + srcFile + '.js'
		#print srcFile
		readFile = open(FilePath)
		for line in readFile:
			line = line.strip()
			if 'clover.srcFileLines = ' in line:
				line = line.replace('clover.srcFileLines = ', '')
				line = line[1:-1]
				#print line

				testItems = []
				if '],' not in line:
					testItems = testItems.append(line)
				else:
					testItems = line.split('],')
				
				
				LineItem = -1
				for testItem in testItems:
					LineItem = LineItem + 1
					testItem = testItem.strip()
					testItem = testItem.replace(']', '')
					testItem = testItem.replace('[', '')
					if testItem == '':
						continue
					#print testItem
					testIDs = testItem.split(',')
					#print testIDs
					for testID in testIDs:
						testID = testID.strip()
						testID = int(testID)
						#print 'line ' + str(LineItem)+ 'is covered by ' + str(testID)
						StateCovMatrix[testID][LineItem + currenPtr] = 1
						if (LineItem + currenPtr) in MethodLineList:
							MethodCovMatrix[testID][LineItem + currenPtr] = 1
						if (LineItem + currenPtr) in ConditionLineList:
							CondCovMatrix[testID][LineItem + currenPtr] = 1
		readFile.close()
	reacordMatrix(StateCovMatrix, ResultRootPath + '/'+ subName + '/stateMatrix.txt', testSum, UnitSum)
	reacordMatrix(MethodCovMatrix, ResultRootPath + '/'+ subName + '/methodMatrix.txt', testSum, UnitSum)
	reacordMatrix(CondCovMatrix, ResultRootPath + '/'+ subName + '/condMatrix.txt', testSum, UnitSum)

def reacordMatrix(TheMatrix, recordPath, testSum, UnitSum):
	writefile = open(recordPath, 'w')
	for i in range(0, testSum):
		for j in range(0, UnitSum):
			writefile.write(str(TheMatrix[i][j]))
		writefile.write('\n')
	writefile.close()

#map test id and test name
def mapTest(TestFileList, xmlFilePath):
	testNumber = 0


#get test number
	for testFile in TestFileList:
		htmlPath = xmlFilePath + '/' + testFile + '.html'
		htmlFile = open(htmlPath)
		soup = BeautifulSoup(htmlFile)
		htmlFile.close()
		tdList = soup.findAll('td', {'id' : re.compile('tc-')})
		for tdItem in tdList:
			testID = str(tdItem.attrs['id'])
			testID = testID.replace('tc-', '')
			if int(testID) + 1 > testNumber:
				testNumber = int(testID) + 1
			'''
			if testID not in testIDSet:
				print str(testID)
				testIDSet.append(testID)
				testNumber = testNumber + 1'''

#construct map 

	mapIdName = []
	for i in range(0, testNumber):
		mapIdName.append('NaN')
	#print 'number ' + str(testNumber)

	for testFile in TestFileList:
		htmlPath = xmlFilePath + '/' + testFile + '.html'
		htmlFile = open(htmlPath)
		soup = BeautifulSoup(htmlFile)
		htmlFile.close()
		tdList = soup.findAll('td', {'id' : re.compile('tc-')})
		for tdItem in tdList:
			testID = str(tdItem.attrs['id'])
			testID = testID.replace('tc-', '')
			methodName = tdItem.find('span', {'class' : 'sortValue'})
			methodName = str(methodName.text)
			methodName = methodName.replace('.', '/')
			mapIdName[int(testID)] = methodName
	
	#for item in mapIdName:
	#	print item
	return mapIdName








if __name__ == "__main__":
	#SubjectList = GetSuccessFile(SubjectRootPath + '/cloverConclusion.txt', SubjectRootPath + '/SuccessSubjectList.txt')
	
	#anaMain(SubjectRootPath + '/' + 'hbase-hadoop-compat' + '/cloverResult/statement/site/clover', 'hbase-hadoop-compat')
	
	
	#SubjectList = readSubjectList(SubjectRootPath + '/SuccessSubjectList.txt')
	SubjectList = ['chukwa']
	for sub in SubjectList:
		print 'SUBJECT ' + sub
		resultDir = ResultRootPath  + '/' + sub
		if os.path.exists(resultDir):
			shutil.rmtree(resultDir)
		os.mkdir(resultDir)
		
		anaMain(SubjectRootPath + '/' + sub + '/cloverResult/statement/site/clover', sub)