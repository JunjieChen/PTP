import os
import datetime
import os.path
import subprocess as subp
import sys
import thread
import random

#projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','chromecast-java-api-v2','geo','are-we-consistent-yet','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master']
projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','geo','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master','commons-dbcp','blueflood','commons-io','hivemall','languagetool','stream-lib','jsprit','RoaringBitmap','commons-math']
os.system('mkdir anonymous/train') # anonymous processing
for pro in projects:
	f=open('./trainori/'+pro+'.csv')
	lines=f.readlines()
	f.close()
	result=open('anonymous/train/'+pro+'.csv','w') # anonymous processing
	result.write(lines[0])
	classmapins=dict()
	for i in range(1,len(lines)):
		key=lines[i].strip().split(',')[-1]
		value=lines[i].strip()

		if key not in classmapins.keys():
			classmapins[key]=[]
			classmapins[key].append(value)
		else:
			classmapins[key].append(value)

	maxlen=0
	for key in classmapins.keys():
		if len(classmapins[key])>maxlen:
			maxlen=len(classmapins[key])

	for key in classmapins.keys():
		if len(classmapins[key])<maxlen:
			upper=len(classmapins[key])-1
			for i in range(maxlen-len(classmapins[key])):
				tmp=random.randint(0,upper)
				classmapins[key].append(classmapins[key][tmp])

	
	for key in classmapins.keys():
		result.write('\n'.join(classmapins[key])+'\n')

	result.close()










