

import  xml.dom.minidom
import os
import time  
import random
from datetime import datetime 

rootPath = 'anonymous/projects'# anonymous processing
mutantSum = 0

sequenceType = [
'SequenceTTStatement.txt',
'SequenceTTMethod.txt',
'SequenceGeneticStatement.txt',
'SequenceGeneticMethod.txt',
'SequenceGAStatement.txt',
'SequenceGAMethod.txt',
'SequenceARTStatement.txt',
'SequenceARTMethod.txt',
'SequenceTime.txt',
'SequenceTimeAdditionalStatement.txt',
'SequenceTimeAdditionalMethod.txt',
'SequenceDoubleTimeAdditionalStatement.txt',
'SequenceDoubleTimeAdditionalMethod.txt'
]


resultType = [
'NEWTTStatement',
'NEWTTMethod',
'NEWGeneticStatement',
'NEWGeneticMethod',
'NEWGAStatement',
'NEWGAMethod',
'NEWARTStatement',
'NEWARTMethod',
'NEWTime',
'NEWTimeAdditionalStatement',
'NewTimeAdditionalMethod',
'NewDoubleTimeAdditionalStatement',
'NewDoubleTimeAdditionalMethod'
]

def generateMutantGroup(writepath):
	global mutantSum
	global groupSum 
	groupSum = mutantSum / 5
	mutantGroup = [[0 for col in range(5)] for row in range(groupSum)]
	mutantarray = []
	for i in range(0, mutantSum):
		mutantarray.append(i)
	random.shuffle(mutantarray)
	ptr= 0 
	writefile = open(writepath, 'w')
	for i in range(0, groupSum):
		for j in range(0, 5):
			mutantGroup[i][j] = mutantarray[ptr]
			ptr = ptr + 1
			writefile.write(str(mutantGroup[i][j]) + ' ')
		writefile.write('\n')
	writefile.close()
	return mutantGroup

def readSubjectList(readFilePath):
	SubjectList = []
	readFile = open(readFilePath)
	for line in readFile:
		SubjectList.append(line.strip())
	readFile.close()
	return SubjectList

def readKillMatrix(readMutantPath):
	global mutantSum
	readfile = open(readMutantPath)
	lines = readfile.readlines()
	mutantSum = len(lines)
	readfile.close()
	
	#killMatrix = [[0 for col in range(testSum)] for row in range(mutantSum)]
	killMatrix = []
	for line in lines:
		kills = list(line.strip())
		killMatrix.append(kills)
	return killMatrix

def readMutantGroup(readpath):
	readfile = open(readpath)
	lines = readfile.readlines()
	readfile.close()
	mutantGroup = []
	for line in lines:
		line = line.strip()
		items = line.split(' ')
		tmp = []
		for item in items:
			tmp.append(int(item))
		mutantGroup.append(tmp)
	return mutantGroup

def readSequence(readpath, testMap):
	sequence = []
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		sequence.append(testMap[line])
	readfile.close()
	return sequence

def getNewMetricsResult(testList, testMap, timeList,  mutantGroup, killMatrix, path):
	global sequenceType
	global resultType
	global mutantSum
	for i in range(0, 13):
		readpath = path + '/' + sequenceType[i]
		sequence = readSequence(readpath, testMap)
		groupSum = mutantSum / 5
		csvPath = path + '/CSV'+  resultType[i] + '.csv'
		writeCsvFile = open(csvPath, 'w')
		for j in range(0, groupSum):
			tmpresultlist = []
			mutantlist = []
			for k in range(0, 5):
				mutantlist.append(mutantGroup[j][k])
			writepath = path + '/' + resultType[i] + '_' + str(j)
			tmpresultlist = recordTimeMetricsSingleGroup(testList, timeList, sequence, mutantlist, killMatrix, writepath)
			earlytime, latetime, avetime = calThreeValue(tmpresultlist)
			writeCsvFile.write(str(earlytime) + ',' + str(latetime) + ',' + str(avetime) + '\n')
		writeCsvFile.close()

def calThreeValue(tmpresultlist):
	earlytime = 1000000000
	latetime = -1
	avetime = 0
	for i in range(0, 5):
		avetime = avetime + tmpresultlist[i]
		if tmpresultlist[i] < earlytime:
			earlytime = tmpresultlist[i]
		if tmpresultlist[i] > latetime:
			latetime = tmpresultlist[i]
	return earlytime, latetime, (avetime * 1.0 / 5)


def recordTimeMetricsSingleGroup(testList, timeList, sequence, mutantGroup, killMatrix, writepath):
	tmpresultlist = []
	testSum = len(testList)
	writefile = open(writepath, 'w')
	for i in range(0, 5):
		currentMutant = mutantGroup[i]
		exeTests = 0
		exeTimes = 0
		for j in range(0, testSum):
			currentTest = sequence[j]
			exeTests = exeTests + 1
			exeTimes = exeTimes + timeList[currentTest]
			if killMatrix[currentMutant][currentTest] == '1':
				break
		tmpresultlist.append(exeTimes)
		writefile.write(str(currentMutant) + ' ' + str(exeTests) + ' ' + str(exeTimes) + '\n')
	writefile.close()
	return tmpresultlist


def recordTime(timeList, writepath):
	writefile = open(writepath, 'w')
	for item in timeList:
		writefile.write(str(item) + '\n')
	writefile.close()

def recordTimeOrder(testList, sequence, writepath):
	writefile = open(writepath, 'w')
	testSum = len(testList)
	for i in range(0, testSum):
		writefile.write(testList[sequence[i]] + '\n')
	writefile.close()

def getTimeofEachTestold(dirpath, testList):
	testSum = len(testList)
	timeList = [100000000.0 for i in range(testSum)]
	files = os.listdir(dirpath)
	for file in files:
		if file.endswith('.xml') == False:
			continue
		dom = xml.dom.minidom.parse(dirpath + '/' + file)
		root = dom.documentElement
		testmethods = root.getElementsByTagName('testcase')
		for testmethod in testmethods:
			testname = testmethod.getAttribute('classname') + '.' + testmethod.getAttribute('name')
			testname = testname.replace('.', '/')
			testTime = testmethod.getAttribute('time')
			if testname not in testList:
				continue
			testID = testList.index(testname)
			timeList[testID] = float(testTime)
	return timeList

def getTimeofEachTest(dirpath, testList):
	testSum = len(testList)
	timeList = [100000000.0 for i in range(testSum)]
	readfile = open(dirpath)
	for line in readfile:
		line = line.strip()
		tmpname = line.split(' ')[0]
		tmptime = line.split(' ')[1]
		tmpname = tmpname.replace('.', '/')
		tmpname = tmpname.replace('$', '/')
		if '[' in tmpname:
			tmpname = tmpname.split('[')[0]
		if tmpname not in testList:
			continue
		testID = testList.index(tmpname)
		timeList[testID] = float(tmptime)
	readfile.close()
	for i in range(0, len(testList)):
		if timeList[i] == 100000000:
			testID = testList.index(testList[i])
			timeList[i] = timeList[testID]
	return timeList


def orderTestOntime(timeList):
	testSum = len(timeList)
	sequence = [0 for i in range(testSum)]

	copyList = []
	for i in range(0, testSum):
		copyList.append((i, timeList[i]))
		#copyList[str(i)] = timeList[i]
	#print copyList
	start_ = datetime.utcnow()
	OrderList = sorted(copyList, key=lambda x:x[1])
	end_ = datetime.utcnow()
	print 'time order cost : ' + str(end_ - start_)
	#print OrderList
	
	count = 0
	for keyItem in OrderList:
		sequence[count] = keyItem[0]
		count = count + 1
	return sequence

def readTestMap(readpath):
	testMap = {}
	count = 0
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		testMap[line] = count
		count = count + 1
	readfile.close()
	return testMap
	
def readTestList(readpath):
	testList = []
	count = 0
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		testList.append(line)
	readfile.close()
	return testList

def readTimeList(readpath):
	timeList = []
	readfile = open(readpath)
	for line in readfile:
		line = line.strip()
		timeList.append(float(line))
	readfile.close()
	return timeList

if __name__ == '__main__':
	SubjectList = readSubjectList(rootPath + '/SuccessSubjectList.txt')
	#SubjectList  = ['camel-core']
	for sub in SubjectList:
		print 'SUBJECT ' + sub
		subpath = rootPath + '/R' + sub 
		testList = readTestList(subpath + '/coverage/' + sub + '/testList')
		testMap = readTestMap(subpath + '/coverage/' + sub + '/testList')
		killMatrix = readKillMatrix(subpath + '/mutant/' + sub + '/mutantKillMatrix')
		#timeList = getTimeofEachTest(rootPath + '/' + sub + '/ExeTimeLog.txt', testList)
		timeList = readTimeList(subpath + '/result/' + sub + '/exeTime')
		#recordTime(timeList, subpath + '/result/' + sub + '/exeTime')
		sequence = orderTestOntime(timeList)
		recordTimeOrder(testList, sequence, subpath + '/result/' + sub + '/SequenceTime.txt')
		mutantGroup = generateMutantGroup(subpath + '/result/' + sub + '/mutantGroup')
		#mutantGroup = readMutantGroup(rootPath + '/result/' + sub + '/mutantGroup')
		getNewMetricsResult(testList, testMap, timeList,  mutantGroup, killMatrix, subpath + '/result/' + sub)