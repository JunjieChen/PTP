import xgboost as xgb
import os,sys,time
#projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','chromecast-java-api-v2','geo','are-we-consistent-yet','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master']
#projects=['php-5.5.28','php-5.6.23','php-7.0.5','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0']
#projects=['mapdb-mapdb-1.0.9','php-5.6.23']
projects=['assertj-core','asterisk-java','ews-java-api','gdx-artemis-master','gson-fire','jackson-datatype-guava','jasmine-maven-plugin','java-apns','jopt-simple','la4j','lambdaj-master','LastCalc-0.1','metrics-core','raml-java-parser-master','redline-smalltalk-master','rome-1.5.0','scribe-java','vraptor_archive','camel-core','chukwa','commons-pool','hbase-1.2.2','mapdb-mapdb-1.0.9','OpenTripPlanner-otp-0.20.0','php-5.6.23','DotCi','ddd-cqrs-sample','tamper-master','spring-retry-master','geo','geohash-java','commons-email','exp4j','cloudhopper-smpp','joss','HTTP-Proxy-Servlet','dictomaton','cucumber-reporting','jackson-core-master','spring-data-solr','webbit-master','commons-dbcp','blueflood','commons-io','hivemall','languagetool','stream-lib','jsprit','RoaringBitmap','commons-math']

traindir='anonymous/trainsvm' # anonymous processing
testdir='anonymous/testsvm'
rootdir='../data/predictdata' # anonymous processing

f=open('labeloriset.csv')
lines=f.readlines()
f.close()

iterationcnt=sys.argv[1]
depthvalue=sys.argv[2]

result=open('result.txt.'+depthvalue+'.'+iterationcnt,'w')
for i in range(len(projects)):
	pro=projects[i]
	label=lines[i].strip().split(',')[2]

	propath=rootdir+'/'+pro
	if not os.path.exists(propath):
		continue

	dtrain = xgb.DMatrix(traindir+'/'+pro+'.svm.txt')
	dtest = xgb.DMatrix(testdir+'/'+pro+'.svm.txt')

	param = {}
	# use softmax multi-class classification
	param['objective'] = 'multi:softmax'
	# scale weight of positive examples
	param['eta'] = 0.1
	param['max_depth'] = int(depthvalue)
	param['silent'] = 1
	param['nthread'] = 6
	param['num_class'] = 3
	#param['max_delta_step']=1
	plst = param.items()
	# plst += [('eval_metric', 'auc')] # Multiple evals can be handled in this way
	# plst += [('eval_metric', 'ams@0')]

	# evallist  = [(dtest,'eval'), (dtrain,'train')]

	evallist = [ (dtrain,'train'), (dtest, 'test') ]

	num_round = int(iterationcnt)
	initial0=time.time()
	bst = xgb.train( plst, dtrain, num_round, evallist )
	start=time.time()
	pred = bst.predict( dtest );
	end=time.time()
	print pro+'===>'+label
	print pred

	result.write(pro+','+label+',')
	result.write(str(pred[0])+','+str(start-initial0)+','+str(end-start)+'\n')
	result.flush()
	# bst.save_model('0001.model')

	# # dump model
	# bst.dump_model('dump.raw.txt')
	# # dump model with feature map
	# bst.dump_model('dump.raw.txt','featmap.txt')
result.close()


