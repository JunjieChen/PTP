import os
import pprint
import shutil
originlpath = 'anonymous/projects' # anonymous processing
basepath = "anonymous/projects/mapdb" # anonymous processing
TestList = []
IDList = {}

def unzip_gzfile(projectname):
	global basepath
	global originalpath
	path = basepath + '/mutant/' + projectname+  '/assertion-files-cover/'
	if os.path.exists(path):
		shutil.rmtree(path)
	cmdline = 'cp -rf ' + originlpath + '/' + projectname +  '/assertion-files-cover ' + basepath + '/mutant/' + projectname
	os.system(cmdline)
	os.chdir(path)
	os.system('for ARK in ./*.gz; do gunzip $ARK; done')

def getTestSum(projectname):
	global basepath
	global TestList
	global IDList
	TestList = []
	path = basepath + '/coverage/' + projectname +  '/testList'
	readfile = open(path)
	count = 0
	for line in readfile:
		line = line.strip()
		TestList.append(line)
		IDList[line] = count
		count = count + 1
	readfile.close()

def get_mutant_info(projectname):
	global basepath
	global TestList
	global IDList
	testSum = len(TestList)
	path = basepath + '/mutant/' + projectname+"/assertion-files-cover"
	files = os.listdir(path)
	mutantSum = len(files)
	KillMatrix = [[0 for col in range(testSum)] for row in range(mutantSum)] #matix[i][j] mutant is is kill by test j
	mutantcount = 0
	killFlag = False
	for eachfile in files:
		if killFlag == True:
			mutantcount = mutantcount + 1
			killFlag = False
		eachfilepath = path + '/' + eachfile
		openfile = open(eachfilepath)
		lines = openfile.readlines()
		openfile.close()
		if len(lines) == 1:
			continue
		for eachline in lines:
			eachline = eachline.strip()
			if "MutationDetails" in eachline:
				print str(mutantcount) + ' ' + eachfile 
				print str(mutantcount) + ' ' + eachline
				continue

			elif "FAILEDWITHOUTASSERT_____" in eachline:
				if "(" not in eachline:
					continue
				testclass = eachline.split("(")[1].replace(")","").strip('\n').split(":")[0]
				testmethod = eachline.split(":")[1].split("(")[0].replace(testclass+".","")
				testname = testclass+":"+testmethod
				testname = testname.replace(" ","")
				testname = testname.split(':')[0] + '.' + testname.split(':')[1]
				testname = testname.replace('.' , '/')
				if testname in TestList:
					killFlag = True
					testid = IDList[testname]
					KillMatrix[mutantcount][testid] = 1
					print 'exception killed by ' + testname
			elif ":true" in eachline or ":false" in eachline:
				testname = eachline.split(":")[0] + "." + eachline.split(":")[1]
				testname = testname.replace('.', '/')
				if testname not in TestList:
					continue
				if ":false" in eachline:
					killFlag = True
					testid = IDList[testname]
					KillMatrix[mutantcount][testid] = 1
					print 'assert killed by ' + testname
	#record the matrix
	resultpath = basepath + '/mutant/' + projectname + '/mutantKillMatrix'
	mutantcount = mutantcount + 1
	writefile = open(resultpath ,'w')
	for i in range(0, mutantcount):
		for j in range(0, testSum):
			writefile.write(str(KillMatrix[i][j]))
		writefile.write('\n')
	writefile.close()

def readsubjectList():
	global originlpath
	subList = []
	readfile = open(originlpath + '/SuccessSubjectList.txt')
	for line in readfile:
		line = line.strip()
		subList.append(line)
	readfile.close()
	return subList


if __name__ == '__main__':

	#projects = readsubjectList()
	projects = ['mapdb-mapdb-1.0.9']
	for project in projects:
		print "dealing with: ",project
		unzip_gzfile(project)
		getTestSum(project)
		get_mutant_info(project)

