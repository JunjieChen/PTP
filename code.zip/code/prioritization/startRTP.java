import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.AbstractDocument.LeafElement;

public class startRTP {

	public static String rootsubjectpath = "anonymous/projects"; //anonymous processing
	
	
	public static List<String> SubList = new ArrayList<String>();
	public static int covMatrix[][];
	public static List<String> TestList = new ArrayList<String>();
	public static int testNum = 0;
	public static int mutantNum = 0; 
	
	//read the sublist to be handled
	public static void readSubList() throws IOException{
		SubList.clear();
		FileReader fr = new FileReader(new File(rootsubjectpath + "/anonymouslist1.txt")); //anonymous processing
		BufferedReader br = new BufferedReader(fr);
		String line;
		while ((line = br.readLine()) != null){
			line = line.trim();
			SubList.add(line);
		}
		br.close();
		fr.close();
		
	}
	
	// read the coveMatrix and TestList
	public static void readMatrixandTest(String Subname) throws IOException{
		
		testNum = 0;
		mutantNum = 0;
		
		//get the test list
		
		TestList.clear();
		FileReader fr = new FileReader(new File(rootsubjectpath + "/R" + Subname + "/coverage/" + Subname  + "/testList"));
		//FileReader fr = new FileReader(new File(rootsubjectpath  + "/coverage/" + Subname  + "/testList"));
		BufferedReader br = new BufferedReader(fr);
		String line;
		while ((line = br.readLine()) != null){
			line = line.trim();
			TestList.add(line);
		}
		br.close();
		fr.close();
		
		
		//create the dir
		String resultDir = rootsubjectpath + "/R" + Subname  + "/result/" + Subname;
	//	String resultDir = rootsubjectpath  + "/result/" + Subname;
		File resultFile = new File(resultDir);
		if (!resultFile.exists())
			resultFile.mkdirs();
		
	}
	
	
	public static void writeresult(String writepath, int sequence[]) throws IOException{
		FileWriter fw = new FileWriter(new File(writepath));
		BufferedWriter bw = new BufferedWriter(fw);
		for(int j = 0; j < sequence.length; j++){ 
			String testname = TestList.get(sequence[j]);
			bw.write(testname);
			bw.newLine();
		}
		bw.close();
		fw.close();
		
	}

	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		long start, end;
		
		readSubList();
		String Subname;
		for(int i = 0; i < SubList.size(); i++){
			Subname = SubList.get(i);
			readMatrixandTest(Subname);
			
			System.out.println("sub " + Subname);
			TimeAdditional ta = new TimeAdditional(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "stateMatrix.txt", rootsubjectpath + "/R" + Subname  + "/result/" + Subname +"/exeTime");
			start = System.currentTimeMillis();
			int[] sequence = ta.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("timeadditional st " +  (end - start));
			writeresult(rootsubjectpath + "/R" + Subname  + "/result/" + Subname + "/SequenceTimeAdditionalStatement.txt",sequence);
			
			ta = new TimeAdditional(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "methodMatrix.txt", rootsubjectpath + "/R" + Subname  + "/result/" + Subname +"/exeTime");
			start = System.currentTimeMillis();
			sequence = ta.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("timeadditional md " +  (end - start));
			writeresult(rootsubjectpath + "/R" + Subname  + "/result/" + Subname + "/SequenceTimeAdditionalMethod.txt",sequence);
			/*
			DoubleTimeAdditional da = new DoubleTimeAdditional(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "stateMatrix.txt", rootsubjectpath + "/R" + Subname  + "/result/" + Subname +"/exeTime");
			start = System.currentTimeMillis();
			sequence = da.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("doubletimeadditional st " +  (end - start));
			writeresult(rootsubjectpath + "/R" + Subname  + "/result/" + Subname + "/SequenceDoubleTimeAdditionalStatement.txt",sequence);
			
			da = new DoubleTimeAdditional(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "methodMatrix.txt", rootsubjectpath + "/R" + Subname  + "/result/" + Subname +"/exeTime");
			start = System.currentTimeMillis();
			sequence = da.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("doubletimeadditional md " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname  + "/result/" + Subname + "/SequenceDoubleTimeAdditionalMethod.txt",sequence);
			*/

			GreedyTotal tt = new GreedyTotal(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "stateMatrix.txt");
			start = System.currentTimeMillis();
			sequence = tt.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("GreedyT st " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname + "/result/" + Subname + "/SequenceTTStatement.txt",sequence);

			tt = new GreedyTotal(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "methodMatrix.txt");
			start = System.currentTimeMillis();
			sequence = tt.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("GreedyT method " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname + "/result/" + Subname + "/SequenceTTMethod.txt",sequence);

			//GA  statement/ method/ cond
			GreedyAdditional ga = new GreedyAdditional(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "stateMatrix.txt");
			start = System.currentTimeMillis();
			sequence = ga.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("GreedyA st " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname+ "/result/" + Subname + "/SequenceGAStatement.txt",sequence);
			
			
			ga = new GreedyAdditional(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "methodMatrix.txt");
			start = System.currentTimeMillis();
			sequence = ga.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("GreedyA method " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname+ "/result/" + Subname + "/SequenceGAMethod.txt",sequence);

			
			//ART  statement/ method/ cond
			ARTMaxMin ar = new ARTMaxMin(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "stateMatrix.txt");
			start = System.currentTimeMillis();
			sequence = ar.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("ART st " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname+ "/result/" + Subname + "/SequenceARTStatement.txt",sequence);
			
			
			ar = new ARTMaxMin(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "methodMatrix.txt");
			start = System.currentTimeMillis();
			sequence = ar.getSelectedTestSequence();
			end = System.currentTimeMillis();
			System.out.println("ART method " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname+ "/result/" + Subname + "/SequenceARTMethod.txt",sequence);

			//Genetic  statement/ method/ cond
			Genetic gt = new Genetic(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "stateMatrix.txt");
			start = System.currentTimeMillis();
			sequence = gt.StartGeneration();
			end = System.currentTimeMillis();
			System.out.println("Genetic st " +  (end - start));
			writeresult(rootsubjectpath  + "/R" + Subname + "/result/" + Subname + "/SequenceGeneticStatement.txt",sequence);
			
			
			gt = new Genetic(rootsubjectpath + "/R" + Subname  + "/coverage/" + Subname, "methodMatrix.txt");
			start = System.currentTimeMillis();
			sequence = gt.StartGeneration();
			end = System.currentTimeMillis();
			System.out.println("Genetic Method " +  (end - start));
			writeresult(rootsubjectpath + "/R" + Subname + "/result/" + Subname + "/SequenceGeneticMethod.txt",sequence);
			
		}		
		
	}

}
